/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Message;

/**
 *
 * @author Student
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Message {

    private String messageID;
    private String recipient;
    private String message;
    private String messageHash;
    private int messageNumber;

    private static int totalMessagesSent = 0;

    private static List<Message> sentMessages = new ArrayList<>();

    public Message(String recipient, String message, int messageNumber) {
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.message = message;
        this.messageNumber = messageNumber;
        this.messageHash = createMessageHash();
    }
    // Constructor used for testing a specific message ID
public Message(String recipient, String message, int messageNumber, String testMessageID) {
    this.messageID = testMessageID;
    this.recipient = recipient;
    this.message = message;
    this.messageNumber = messageNumber;
    this.messageHash = createMessageHash();
}

    // Generates a random 10-digit message ID
    private String generateMessageID() {
        Random random = new Random();

        long number = 1000000000L
                + (long) (random.nextDouble() * 9000000000L);

        return String.valueOf(number);
    }

    // Checks that the message ID is not more than 10 characters
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    // Validates recipient cell number
    public String checkRecipientCell() {

        if (recipient != null && recipient.matches("^\\+27[0-9]{9}$")) {
            return "Cell phone number successfully captured.";
        }

        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    // Checks message length
    public String checkMessageLength() {

        if (message != null && message.length() <= 250) {
            return "Message ready to send.";
        }

        int length = message == null ? 0 : message.length();

        return "Message exceeds 250 characters by "
                + (length - 250)
                + "; please reduce the size.";
    }

    // Creates the message hash
    public String createMessageHash() {

        if (messageID == null || message == null || message.trim().isEmpty()) {
            return "";
        }

        String[] words = message.trim().split("\\s+");

        String firstWord = words[0].replaceAll("[^a-zA-Z0-9]", "");
        String lastWord = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");

        String firstTwoDigits = messageID.substring(0, 2);

        return (firstTwoDigits + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    // Allows user to send, disregard or store message
    public String SentMessage(String choice) {

        if (choice.equalsIgnoreCase("Send")
                || choice.equalsIgnoreCase("Send Message")) {

            if (!checkRecipientCell().equals("Cell phone number successfully captured.")) {
                return checkRecipientCell();
            }

            if (!checkMessageLength().equals("Message ready to send.")) {
                return checkMessageLength();
            }

            sentMessages.add(this);
            totalMessagesSent++;

            return "Message successfully sent.";

        } else if (choice.equalsIgnoreCase("Disregard")
                || choice.equalsIgnoreCase("Discard")
                || choice.equalsIgnoreCase("Disregard Message")) {

            return "Press 0 to delete the message.";

        } else if (choice.equalsIgnoreCase("Store")
                || choice.equalsIgnoreCase("Store Message")) {

            storeMessage();

            return "Message successfully stored.";

        } else {
            return "Invalid option.";
        }
    }

    // Prints all sent messages
    public String printMessages() {

        StringBuilder output = new StringBuilder();

        for (Message msg : sentMessages) {

            output.append("Message ID: ")
                    .append(msg.messageID)
                    .append("\n");

            output.append("Message Hash: ")
                    .append(msg.messageHash)
                    .append("\n");

            output.append("Recipient: ")
                    .append(msg.recipient)
                    .append("\n");

            output.append("Message: ")
                    .append(msg.message)
                    .append("\n\n");
        }

        return output.toString();
    }

    // Returns total number of sent messages
    public int returnTotalMessagess() {
        return totalMessagesSent;
    }

    // Stores message in JSON format
    public void storeMessage() {

        String fileName = "messages.json";

        String jsonMessage = "{"
                + "\"messageID\":\"" + escapeJSON(messageID) + "\","
                + "\"messageHash\":\"" + escapeJSON(messageHash) + "\","
                + "\"recipient\":\"" + escapeJSON(recipient) + "\","
                + "\"message\":\"" + escapeJSON(message) + "\","
                + "\"messageNumber\":" + messageNumber
                + "}";

        try {

            File file = new File(fileName);

            if (!file.exists() || file.length() == 0) {

                FileWriter writer = new FileWriter(fileName);

                writer.write("[\n");
                writer.write(jsonMessage);
                writer.write("\n]");
                writer.close();

            } else {

                String existing = new String(
                        Files.readAllBytes(Paths.get(fileName))
                );

                existing = existing.trim();

                if (existing.endsWith("]")) {
                    existing = existing.substring(0, existing.length() - 1);
                }

                FileWriter writer = new FileWriter(fileName);

                writer.write(existing);

                if (!existing.trim().equals("[")) {
                    writer.write(",");
                }

                writer.write("\n");
                writer.write(jsonMessage);
                writer.write("\n]");
                writer.close();
            }

        } catch (IOException e) {
            System.out.println("Error storing message: " + e.getMessage());
        }
    }

    // Escapes special characters for JSON
    private String escapeJSON(String text) {

        if (text == null) {
            return "";
        }

        return text.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    // Getters
    public String getMessageID() {
        return messageID;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public int getMessageNumber() {
        return messageNumber;
    }
}