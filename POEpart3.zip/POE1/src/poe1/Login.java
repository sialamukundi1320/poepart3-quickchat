/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package poe1;

/**
 *
 * @author Student
 */

import java.util.regex.Pattern;

public class Login {

    private String username;
    private String password;
    private String cellPhoneNumber;

    private String registeredUsername;
    private String registeredPassword;

    public Login(String username, String password, String cellPhoneNumber) {
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
    }

    // Checks username formatting
    public boolean checkUserName() {
        return username != null
                && username.contains("_")
                && username.length() <= 5;
    }

    // Checks password complexity
    public boolean checkPasswordComplexity() {
        if (password == null) {
            return false;
        }

        return password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*[0-9].*")
                && password.matches(".*[^a-zA-Z0-9].*");
    }

    // Checks South African cell phone number formatting
    public boolean checkCellPhoneNumber() {
        if (cellPhoneNumber == null) {
            return false;
        }

        String regex = "^\\+27[0-9]{9}$";

        return Pattern.matches(regex, cellPhoneNumber);
    }

    // Registers the user and returns the appropriate message
    public String registerUser() {

        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        registeredUsername = username;
        registeredPassword = password;

        return "User registered successfully.";
    }

    // Checks whether login details match registered details
    public boolean loginUser(String enteredUsername, String enteredPassword) {

        return registeredUsername != null
                && registeredPassword != null
                && registeredUsername.equals(enteredUsername)
                && registeredPassword.equals(enteredPassword);
    }

    // Returns login status message
    public String returnLoginStatus(boolean loginStatus) {

        if (loginStatus) {
            return "Welcome ,  it is great to see you.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }

    // Getters
    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getCellPhoneNumber() {
        return cellPhoneNumber;
    }
}