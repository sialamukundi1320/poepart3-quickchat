/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
import Message.Message;
import java.util.Scanner;
import poe1.Login;

public class QuickChat {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // ==============================
        // PART 1: REGISTRATION
        // ==============================

        System.out.println("===== REGISTRATION =====");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        System.out.print("Enter South African cell phone number (+27): ");
        String cellPhone = input.nextLine();

        Login login = new Login(username, password, cellPhone);

        System.out.println(login.registerUser());

        if (!login.checkUserName()
                || !login.checkPasswordComplexity()
                || !login.checkCellPhoneNumber()) {

            System.out.println("Registration failed.");
            input.close();
            return;
        }

        // ==============================
        // PART 1: LOGIN
        // ==============================

        System.out.println("\n===== LOGIN =====");

        System.out.print("Enter username: ");
        String loginUsername = input.nextLine();

        System.out.print("Enter password: ");
        String loginPassword = input.nextLine();

        boolean loginStatus = login.loginUser(
                loginUsername,
                loginPassword
        );

        System.out.println(login.returnLoginStatus(loginStatus));

        if (!loginStatus) {
            input.close();
            return;
        }

        // ==============================
        // PART 2: QUICKCHAT
        // ==============================

        System.out.println("\nWelcome to QuickChat.");

        System.out.print("How many messages would you like to enter? ");

        int numberOfMessages;

        try {
            numberOfMessages = Integer.parseInt(input.nextLine());

            if (numberOfMessages < 0) {
                System.out.println("Please enter a valid number.");
                input.close();
                return;
            }

        } catch (NumberFormatException e) {
            System.out.println("Invalid number entered.");
            input.close();
            return;
        }

        // ==============================
        // PART 3: ARRAYS
        // ==============================

        // Parallel arrays to store sent messages
        String[] messageIDs = new String[numberOfMessages];
        String[] messageHashes = new String[numberOfMessages];
        String[] recipients = new String[numberOfMessages];
        String[] messages = new String[numberOfMessages];

        int messagesProcessed = 0;
        int sentArrayCount = 0;

        // ==============================
        // QUICKCHAT MENU
        // ==============================

        while (true) {

            System.out.println("\n===== QUICKCHAT MENU =====");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");
            System.out.println("4. Display the longest message");
            System.out.println("5. Search messages by recipient");

            System.out.print("Choose an option: ");

            String choice = input.nextLine();

            switch (choice) {

                // ==============================
                // OPTION 1: SEND MESSAGES
                // ==============================

                case "1":

                    if (messagesProcessed >= numberOfMessages) {
                        System.out.println("You have reached your message limit.");
                        break;
                    }

                    while (messagesProcessed < numberOfMessages) {

                        System.out.println("\n===== NEW MESSAGE =====");

                        System.out.print("Enter recipient cell number (+27): ");
                        String recipient = input.nextLine();

                        System.out.print("Enter message: ");
                        String messageText = input.nextLine();

                        Message message = new Message(
                                recipient,
                                messageText,
                                messagesProcessed
                        );

                        // Validate recipient
                        String recipientStatus = message.checkRecipientCell();

                        System.out.println(recipientStatus);

                        // Validate message length
                        String messageStatus = message.checkMessageLength();

                        System.out.println(messageStatus);

                        if (!recipientStatus.equals(
                                "Cell phone number successfully captured.")
                                || !messageStatus.equals("Message ready to send.")) {

                            System.out.println("Message was not processed. Please try again.");
                            continue;
                        }

                        // Message options
                        System.out.println("\n1. Send Message");
                        System.out.println("2. Disregard Message");
                        System.out.println("3. Store Message");

                        System.out.print("Choose an option: ");

                        String messageChoice = input.nextLine();

                        String result;

                        if (messageChoice.equals("1")) {

                            result = message.SentMessage("Send");

                        } else if (messageChoice.equals("2")) {

                            result = message.SentMessage("Disregard");

                        } else if (messageChoice.equals("3")) {

                            result = message.SentMessage("Store");

                        } else {

                            result = "Invalid option.";
                        }

                        System.out.println(result);

                        // Store sent messages inside the arrays
                        if (result.equals("Message successfully sent.")) {

                            messageIDs[sentArrayCount] =
                                    message.getMessageID();

                            messageHashes[sentArrayCount] =
                                    message.getMessageHash();

                            recipients[sentArrayCount] =
                                    message.getRecipient();

                            messages[sentArrayCount] =
                                    message.getMessage();

                            sentArrayCount++;

                            // Display message details
                            System.out.println("\n===== MESSAGE DETAILS =====");

                            System.out.println("Message ID: "
                                    + message.getMessageID());

                            System.out.println("Message Hash: "
                                    + message.getMessageHash());

                            System.out.println("Recipient: "
                                    + message.getRecipient());

                            System.out.println("Message: "
                                    + message.getMessage());
                        }

                        messagesProcessed++;

                        System.out.println("\nMessages processed: "
                                + messagesProcessed
                                + " out of "
                                + numberOfMessages);

                        if (messagesProcessed >= numberOfMessages) {
                            System.out.println("You have completed your messages.");
                            break;
                        }

                        System.out.print(
                                "\nWould you like to enter another message? (yes/no): "
                        );

                        String continueMessages = input.nextLine();

                        if (!continueMessages.equalsIgnoreCase("yes")) {
                            break;
                        }
                    }

                    break;

                // ==============================
                // OPTION 2: COMING SOON
                // ==============================

                case "2":

                    System.out.println("Coming Soon.");

                    break;

                // ==============================
                // OPTION 3: QUIT
                // ==============================

                case "3":

                    System.out.println("\n===== EXITING QUICKCHAT =====");

                    Message finalMessage = new Message("", "", 0);

                    System.out.println("Total messages sent: "
                            + finalMessage.returnTotalMessagess());

                    System.out.println("\nAll sent messages:");

                    System.out.println(finalMessage.printMessages());

                    input.close();
                    return;

                // ==============================
                // OPTION 4: LONGEST MESSAGE
                // ==============================

                case "4":

                    displayLongestMessage(
                            messageIDs,
                            messageHashes,
                            recipients,
                            messages,
                            sentArrayCount
                    );

                    break;

                // ==============================
                // OPTION 5: SEARCH BY RECIPIENT
                // ==============================

                case "5":

                    System.out.print("Enter recipient number to search: ");

                    String searchRecipient = input.nextLine();

                    searchMessagesByRecipient(
                            messageIDs,
                            messageHashes,
                            recipients,
                            messages,
                            sentArrayCount,
                            searchRecipient
                    );

                    break;

                // ==============================
                // INVALID MENU OPTION
                // ==============================

                default:

                    System.out.println("Invalid option. Please choose from 1 to 5.");
            }
        }
    }

    // ==========================================
    // METHOD: DISPLAY THE LONGEST MESSAGE
    // ==========================================

    public static void displayLongestMessage(
            String[] messageIDs,
            String[] messageHashes,
            String[] recipients,
            String[] messages,
            int sentArrayCount) {

        if (sentArrayCount == 0) {
            System.out.println("No sent messages available.");
            return;
        }

        int longestIndex = 0;

        for (int i = 1; i < sentArrayCount; i++) {

            if (messages[i].length() > messages[longestIndex].length()) {
                longestIndex = i;
            }
        }

        System.out.println("\n===== LONGEST MESSAGE =====");

        System.out.println("Message ID: "
                + messageIDs[longestIndex]);

        System.out.println("Message Hash: "
                + messageHashes[longestIndex]);

        System.out.println("Recipient: "
                + recipients[longestIndex]);

        System.out.println("Message: "
                + messages[longestIndex]);

        System.out.println("Message length: "
                + messages[longestIndex].length()
                + " characters");
    }

    // ==========================================
    // METHOD: SEARCH MESSAGES BY RECIPIENT
    // ==========================================

    public static void searchMessagesByRecipient(
            String[] messageIDs,
            String[] messageHashes,
            String[] recipients,
            String[] messages,
            int sentArrayCount,
            String searchRecipient) {

        boolean found = false;

        System.out.println("\n===== SEARCH RESULTS =====");

        for (int i = 0; i < sentArrayCount; i++) {

            if (recipients[i].equals(searchRecipient)) {

                found = true;

                System.out.println("\nMessage ID: "
                        + messageIDs[i]);

                System.out.println("Message Hash: "
                        + messageHashes[i]);

                System.out.println("Recipient: "
                        + recipients[i]);

                System.out.println("Message: "
                        + messages[i]);
            }
        }

        if (!found) {
            System.out.println("No messages found for this recipient.");
        }
    }
}