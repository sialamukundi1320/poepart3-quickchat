/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package Login;

import org.testng.annotations.Test;
import static org.testng.Assert.*;
import poe1.Login;

public class LoginNGTest {

    // Username correctly formatted
    @Test
    public void testUsernameCorrectlyFormatted() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        assertTrue(login.checkUserName());
    }

    // Username incorrectly formatted
    @Test
    public void testUsernameIncorrectlyFormatted() {
        Login login = new Login("kyle!!!!!!!!", "Ch&&sec@ke99!", "+27838968976");

        assertFalse(login.checkUserName());

        assertEquals(
                login.registerUser(),
                "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length."
        );
    }

    // Password meets complexity requirements
    @Test
    public void testPasswordComplexitySuccess() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        assertTrue(login.checkPasswordComplexity());

        assertEquals(
                login.registerUser(),
                "User registered successfully."
        );
    }

    // Password does not meet complexity requirements
    @Test
    public void testPasswordComplexityFailure() {
        Login login = new Login("kyl_1", "password", "+27838968976");

        assertFalse(login.checkPasswordComplexity());

        assertEquals(
                login.registerUser(),
                "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character."
        );
    }

    // Cell phone number correctly formatted
    @Test
    public void testCellPhoneCorrectlyFormatted() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        assertTrue(login.checkCellPhoneNumber());
    }

    // Cell phone number incorrectly formatted
    @Test
    public void testCellPhoneIncorrectlyFormatted() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "08966553");

        assertFalse(login.checkCellPhoneNumber());
    }

    // Login successful
    @Test
    public void testLoginSuccessful() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        login.registerUser();

        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));

        assertEquals(
                login.returnLoginStatus(true),
                "Welcome ,  it is great to see you."
        );
    }

    // Login failed
    @Test
    public void testLoginFailed() {
        Login login = new Login("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        login.registerUser();

        assertFalse(login.loginUser("wrong", "wrong"));

        assertEquals(
                login.returnLoginStatus(false),
                "Username or password incorrect, please try again."
        );
    }
}